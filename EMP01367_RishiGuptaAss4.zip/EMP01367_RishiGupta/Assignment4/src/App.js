import './App.css';
import maq from "./assets/maq.png";
import Posts from './components/Posts/Posts';

function App() {
 
  return (
    <div className="App container">
      <img src={maq}></img>
      <Posts></Posts>
      
    </div>
  );
}

export default App;

import React from 'react'
import { useState,useEffect } from 'react/cjs/react.development'
import PostCard from '../PostCard/PostCard';
import "./Posts.css"
const Posts = () => {

    const [buttonStatus,setbuttonStatus]=useState(false);
    const [name,setName]=useState("");
    const [postText,setpostText]=useState("");
    const [posts,setPosts]=useState([]);

    useEffect(() => {
        if(name && postText)
        setbuttonStatus(true);
        else
        setbuttonStatus(false);
    }, [name,postText,posts]);

    const handleName=(event)=>{
        setName(event.currentTarget.value);     
    }
    const handlepostText=(event)=>{
        setpostText(event.currentTarget.value);
    }
    const handleSubmit=(event)=>{
        event.preventDefault();
        const obj={name:"",postText:""};
        obj["name"]=name;
        obj["postText"]=postText;
        const postsCopy=posts;
        postsCopy.push(obj);
        setPosts(postsCopy);
        setName("");
        setpostText("");
    }
    return (
        <div className="post-container ">
        <div className="post shadow-lg p-3 mb-5 bg-white rounded">
        <h3>New Post</h3>
        <form onSubmit={(event)=>handleSubmit(event)}>
          <input type="text" placeholder="Name..." onChange={(event)=>handleName(event)} value={name}></input>
          <textarea name="comment" form="usrform" placeholder="Write a new post..." onChange={(event)=>handlepostText(event)} value={postText}></textarea>
          <input type="submit" className="btn btn-primary" disabled={!buttonStatus}></input>
        </form>
      </div>
      {posts.length>0?<div className="count"><h3>{posts.length} post(s) added</h3></div>:<div></div>}
      {posts.length>0?
        
       
       
           posts.map((post)=>{
               return(
               <PostCard  postcard={post}></PostCard>);
           })
       
     
    
      :<div className="no-post">No Posts added yet! To get started add new post</div>}
      </div>
    )
}

export default Posts

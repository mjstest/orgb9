import React from 'react'
import Posts from '../Posts/Posts'
import "./PostCard.css"
import { useState,useEffect } from 'react/cjs/react.development'
import {Modal,Button} from 'react-bootstrap';
import Comments from '../Comments/Comments';
const PostCard = (props) => {
    const [buttonStatus,setbuttonStatus]=useState(false);
    const [name,setName]=useState("");
    const [postText,setpostText]=useState("");
    const [posts,setPosts]=useState([]);
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    useEffect(() => {
        if(name && postText)
        setbuttonStatus(true);
        else
        setbuttonStatus(false);
    }, [name,postText,posts]);

    const handleName=(event)=>{
        setName(event.currentTarget.value);     
    }
    const handlepostText=(event)=>{
        setpostText(event.currentTarget.value);
    }
    const handleSubmit=(event)=>{
        event.preventDefault();
        const obj={name:"",postText:""};
        obj["name"]=name;
        obj["postText"]=postText;
        const postsCopy=posts;
        postsCopy.push(obj);
        setPosts(postsCopy);
        console.log(posts);
        setName("");
        setpostText("");
        setShow(false);
    }
    return (
        <div className="container postcard">
            <p className="name-heading">{props.postcard.name}</p>
            <p className="description-heading">{props.postcard.postText}</p>
            <div className="comment-button">
                <p>{posts.length} Comments</p>
                <button className="btn btn-primary" onClick={handleShow}>Add Comment</button>
            </div>
            <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add new comment</Modal.Title>
        </Modal.Header>
        <Modal.Body><div className="post">
        <form onSubmit={(event)=>handleSubmit(event)}>
          <input type="text" placeholder="Name..." onChange={(event)=>handleName(event)} value={name}></input>
          <textarea name="comment" form="usrform" placeholder="Write a new post..." onChange={(event)=>handlepostText(event)} value={postText}></textarea>
          <input type="submit" className="btn btn-primary" disabled={!buttonStatus}></input>
        </form>
      </div></Modal.Body>
      </Modal>
      {
          posts.map((post)=>{
              return <Comments postcard={post}></Comments>
          })
      }
        </div>
    )
}

export default PostCard;

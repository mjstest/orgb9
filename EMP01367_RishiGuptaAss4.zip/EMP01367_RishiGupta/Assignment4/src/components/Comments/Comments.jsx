import React from 'react'
import "./Comments.css"
const Comments = (props) => {
    return (
        <div className="comment-card">
            <p className="name-heading">{props.postcard.name}</p>
            <p className="description-heading">{props.postcard.postText}</p>
        </div>
    )
}

export default Comments;

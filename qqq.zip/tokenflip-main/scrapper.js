const webdriver = require('selenium-webdriver')
const chrome = require('selenium-webdriver/chrome')
const { By, Key, Builder } = webdriver


module.exports = class {
    constructor( tokens, chromeProfilePath, onTokenInitDone, onInitDone, onPriceChange, opts = {} ) {
        this.tokens = tokens
        this.chromeProfilePath = chromeProfilePath

        this._headless = opts.headless || false
        this._newWindow = opts.newWindow || "window" // or "tab"
        this._started = false
        this._initDone = false

        this.options = new chrome.Options().windowSize({ width: 500, height: 800 })
        this.options.addArguments(`--user-data-dir=${chromeProfilePath}`)

        if (this._headless)
            this.options = this.options.headless()

        this.tabHandles = {}
        this.lastValues = {}
        this.lastChanges = {}

        this.onTokenInitDone = onTokenInitDone
        this.onInitDone = onInitDone
        this.onPriceChange = onPriceChange
    }

    buildDriver() {
        this.driver = new Builder()
            .forBrowser('chrome')
            .setChromeOptions(this.options)
            .build()
    }

    async repositionWindow(x, y) {
        if (this._newWindow == "window") {
            const currentRect = await this.driver.manage().window().getRect()
            await this.driver.manage().window().setRect({ ...currentRect, x, y })
        }
    }

    async initUniswapTracking(token) {
        this.repositionWindow(0, 0)
    
        await this.driver.get('https://app.uniswap.org/#/swap')
        await this.driver.findElement(By.className("token-amount-input")).sendKeys(this.tokens[token][2])
        const tokenButtons = await this.driver.findElements(By.className("open-currency-select-button"))
        await tokenButtons[1].click()
        const tokenSearchInput = await this.driver.findElement(By.id("token-search-input"))
        await tokenSearchInput.sendKeys(this.tokens[token][0])
    
        // Wait for token loading
        for (let i = 0; i < 20; i++) {
            await this.driver.sleep(500)
            try {
                await this.driver.findElement(By.xpath(`//div[text()="${token}"]`))
                break
            }
            catch(e) {
                continue
            }
        }
        
        // Check whether token needs to be imported
        try { 
            await this.driver.findElement(By.xpath('//button[text()="Import"]')).click()
            await this.driver.sleep(200)
            await this.driver.findElement(By.xpath('//button[text()="Import"]')).click()
        }
        catch(e) { // Probably import button was not found and token is present within the uniswap system
            try {
                for (let i = 0; i < 20; i++) {
                    await tokenSearchInput.sendKeys(Key.ENTER)
                    await this.driver.sleep(500)
                }
                console.error(`❗️ uniswap Token ${token} loading was not successful`)
            }
            catch(e) { /* sendKeys will break once token is selected */ }
        }
    
        // Wait for token price loading
        try {
            for (let i = 0; i < 20; i++) {
                const tokenAmountInputs = await this.driver.findElements(By.className("token-amount-input"))
                const tokenValue = await tokenAmountInputs[1].getAttribute('value')
                if (tokenValue != "") {
                    this.lastValues[token][0] = tokenValue
                    this.lastChanges[token][0] = Date.now()
                    throw "Price retrieved"
                }
                await this.driver.sleep(500)
    
                // At the same time check for "No liquidity! Click to trade with V2" button, because in that case price will never load
                try {
                    await this.driver.findElement(By.xpath('//a[@href="#/swap?use=V2"]')).click()
                    console.log(`uniswap Token ${token} switched to V2 price`)
                }
                catch(e) { /* Button was not found, continue waiting for price */ }
            }
            console.error(`❗️ uniswap Token ${token} price loading was not successful`)
        }
        catch(e) { /* for loop will throw once the price is loaded */ }
    
        // Check if "Better V2 price" is present
        try {
            await this.driver.findElement(By.xpath('//a[@href="#/swap?use=V2"]')).click()
            console.log(`uniswap Token ${token} switched to V2 price`)
        }
        catch(e) {
            
        }
    
        this.tabHandles[token][0] = await this.driver.getWindowHandle()
    }

    async init1InchTracking(token) {
        this.repositionWindow(500, 0)
    
        await this.driver.get(`https://app.1inch.io/#/56/swap/ETH/${this.tokens[token][1]}`)
    
        try { // Import token
            await this.driver.findElement(By.className('mat-checkbox-inner-container')).click()
            await this.driver.findElement(By.xpath('//span[text()="Continue"]')).click()
        }
        catch(e) { /* Probably token is present (no need to import) */ }
    
        const tokenAmountInputs = await this.driver.findElements(By.className("token-amount"))
        await tokenAmountInputs[0].clear()
        await tokenAmountInputs[0].sendKeys(this.tokens[token][2])
    
        // wait until price loaded
        try {
            for (let i = 0; i < 20; i++) {
                const tokenValue = await tokenAmountInputs[1].getAttribute('value')
                if (tokenValue != "") {
                    this.lastValues[token][1] = tokenValue
                    this.lastChanges[token][1] = Date.now()
                    throw "Price retrieved"
                }
                await this.driver.sleep(500)
            }
            console.error(`❗️ 1inch Token ${token} price loading was not successful`)
        }
        catch(e) { /* for loop will throw once the price is loaded */ }
    
        this.tabHandles[token][1] = await this.driver.getWindowHandle()
    }

    async getPriceUniswap(token) {
        await this.driver.switchTo().window(this.tabHandles[token][0])
        const tokenAmountInputs = await this.driver.findElements(By.className("token-amount-input"))
        const tokenValue = await tokenAmountInputs[1].getAttribute('value')
        if (this.lastValues[token][0] != tokenValue) {
            this.lastValues[token][0] = tokenValue
            this.lastChanges[token][0] = Date.now()
            this.onPriceChange(token, this.lastChanges, this.lastValues)
        }
        // console.log(`uniswap ${token} value: ${tokenValue}, updated ${Date.now() - lastChanges[token][0]} ms ago`)
    }

    async getPrice1Inch(token) {
        await this.driver.switchTo().window(this.tabHandles[token][1])
        const tokenAmountInputs = await this.driver.findElements(By.className("token-amount"))
        let tokenValue = await tokenAmountInputs[1].getAttribute('value')
        if (tokenValue == "") {
            // Press update
            await this.driver.findElement(By.xpath('//*[@id="market-limit-wrap"]/div/div[2]/app-swap-box/app-swap-box-buttons/app-icon-button[1]/button')).click()
            console.log("PRESSING UPDATE")
    
            for(let i = 0; i < 10; i++) {
                tokenValue = await tokenAmountInputs[1].getAttribute('value')
                if (tokenValue != "")
                    break
                await this.driver.sleep(500)
            }
        }
        if (this.lastValues[token][1] != tokenValue) {
            this.lastValues[token][1] = tokenValue
            this.lastChanges[token][1] = Date.now()
            this.onPriceChange(token, this.lastChanges, this.lastValues)
        }
        // console.log(`1inch ${token} value: ${tokenValue}, updated ${Date.now() - lastChanges[token][1]} ms ago`)
    }

    async stop() {
        if (!this._started)
            return

        await this.driver.quit()
        this._started = false
        this._initDone = false
    }

    async start() {
        if (this._started)
            return

        this._started = true
        this.buildDriver()

        // throw 11

        let tokenIdx = 0
        for (const token in this.tokens) {
            this.tabHandles[token] = [ null, null ]
            this.lastValues[token] = [ 0, 0 ]
            this.lastChanges[token] = [ 0, 0 ]
    
            await this.initUniswapTracking(token)
            this.onTokenInitDone(token, this.lastChanges, this.lastValues)
            await this.driver.switchTo().newWindow(this._newWindow)
            await this.init1InchTracking(token)
            this.onTokenInitDone(token, this.lastChanges, this.lastValues)
    
            console.log(`Token ${tokenIdx + 1} initiated`)
    
            if (tokenIdx < Object.keys(this.tokens).length - 1)
                await this.driver.switchTo().newWindow(this._newWindow)
            await this.driver.sleep(50)
    
            tokenIdx += 1
        }

        this._initDone = true
        this.onInitDone(this.lastChanges, this.lastValues)
    
        while (true) {
            for (const token in this.tabHandles) {
                await this.getPriceUniswap(token)
                await this.driver.sleep(50)
                await this.getPrice1Inch(token)
                await this.driver.sleep(50)
    
                const uP = this.lastValues[token][0] == "" ? 0 : parseFloat(this.lastValues[token][0])
                const iP = this.lastValues[token][1] == "" ? 0 : parseFloat(this.lastValues[token][1])
    
                const uU = Math.floor((Date.now() - this.lastChanges[token][0]) / 1000)
                const iU = Math.floor((Date.now() - this.lastChanges[token][1]) / 1000)
    
                const diffPerc = ((Math.max(uP, iP) - Math.min(uP, iP)) * 100 / Math.max(uP, iP)).toFixed(2)
    
                console.log(`${diffPerc} ${token}, ${uP} ${iP}, ${uU}/${iU} s ago`)
            }
        }
    }
}

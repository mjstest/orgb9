const app = require('express')()
const http = require('http').Server(app)
const io = require('socket.io')(http)

const Scrapper = require('./scrapper')

const chromeProfilePath = '/Users/kirillovmr/Library/Application Support/Google/Chrome/Profile 1';

const tokens = {
//  "TOKEN":    ["            <uniswap address>             ", "              <1Inch address>             "]
    // "OIN":      ["0x9aeb50f542050172359a0e1a25a9933bc8c01259", "0x658e64ffcf40d240a43d52ca9342140316ae44fa", "1"],
    "MARSH":    ["0x5a666c7d92E5fA7Edcb6390E4efD6d0CDd69cF37", "0x2FA5dAF6Fe0708fBD63b1A7D1592577284f52256", "1"],
    "RFOX":     ["0xa1d6df714f91debf4e0802a542e13067f31b8262", "0x0a3a21356793b49154fd3bbe91cbc2a16c0457f5", "1"],
    "LPOOL":    ["0x6149c26cd2f7b5ccdb32029af817123f6e37df5b", "0xcfb24d3c3767364391340a2e6d99c64f1cbd7a3d", "1"],
    "CWS":      ["0xac0104cca91d167873b8601d2e71eb3d4d8c33e0", "0xbcf39f0edda668c58371e519af37ca705f2bfcbd", "1"],
    "GUM":      ["0x4f5fa8f2d12e5eb780f6082dd656c565c48e0f24", "0xc53708664b99DF348dd27C3Ac0759d2DA9c40462", "1"],
    "REVO":     ["0x155040625d7ae3e9cada9a73e3e44f76d3ed1409", "0x155040625d7ae3e9cada9a73e3e44f76d3ed1409", "1"],
    "UMB":      ["0x6fc13eace26590b80cccab1ba5d51890577d83b2", "0x6fc13eace26590b80cccab1ba5d51890577d83b2", "1"],
    "O3":       ["0xee9801669c6138e84bd50deb500827b776777d28", "0xee9801669c6138e84bd50deb500827b776777d28", "1"],
    "FORM":     ["0x21381e026ad6d8266244f2a583b35f9e4413fa2a", "0x25a528af62e56512a19ce8c3cab427807c28cc19", "1"],
    "PMON":     ["0x1796ae0b0fa4862485106a0de9b654eFE301D0b2", "0x1796ae0b0fa4862485106a0de9b654eFE301D0b2", "1"],
    "ZEE":      ["0x2eDf094dB69d6Dcd487f1B3dB9febE2eeC0dd4c5", "0x44754455564474a89358b2c2265883df993b12f0", "1"],
    "ODDZ":     ["0xcd2828fc4d8e8a0ede91bb38cf64b1a81de65bf6", "0xcd40f2670cf58720b694968698a5514e924f742d", "1"],
    "POLS":     ["0x83e6f1e41cdd28eaceb20cb649155049fac3d5aa", "0x7e624fa0e1c4abfd309cc15719b7e2580887f570", "1"],
    "FAST":     ["0xc888a0ab4831a29e6ca432babf52e353d23db3c2", "0x4d338614fc25afe6edf3994f331b4bad32fb3c6a", "1"],
    "MTLX":     ["0x2e1e15c44ffe4df6a0cb7371cd00d5028e571d14", "0x5921dee8556c4593eefcfad3ca5e2f618606483b", "1"],
    "8PAY":     ["0xfeea0bdd3d07eb6fe305938878c0cadbfa169042", "0xfeea0bdd3d07eb6fe305938878c0cadbfa169042", "1"],
    "DPET":     ["0xfb62ae373aca027177d1c18ee0862817f9080d08", "0xfb62ae373aca027177d1c18ee0862817f9080d08", "1"],
    "DMOD":     ["0x5f6c5c2fb289db2228d159c69621215e354218d7", "0x002d8563759f5e1eaf8784181f3973288f6856e4", "1"],
    "MOD":      ["0xea1ea0972fa092dd463f2968f9bb51cc4c981d71", "0xd4fbc57b6233f268e7fba3b66e62719d74deecbc", "1"],
    // "MOD":      ["0xea1ea0972fa092dd463f2968f9bb51cc4c981d71", "0xd4fbc57b6233f268e7fba3b66e62719d74deecbc", "1"],
}

let lastChanges = {}
let lastValues = {}

const scrapper = new Scrapper( 
    tokens, 
    chromeProfilePath, 
    (token, _lastChanges, _lastValues) => {
        lastChanges = _lastChanges
        lastValues = _lastValues
        io.emit('tokenInitDone', token, _lastChanges, _lastValues)
    },
    (_lastChanges, _lastValues) => {
        lastChanges = _lastChanges
        lastValues = _lastValues
        io.emit('initDone', _lastChanges, _lastValues)
    },
    (token, _lastChanges, _lastValues) => {
        lastChanges = _lastChanges
        lastValues = _lastValues
        io.emit('priceChange', token, _lastChanges, _lastValues)
    },
    {
        headless: true,
        newWindow: "window",
    }
)


app.get('/', (req, res) => {
   res.sendFile(__dirname + '/index.html')
})


io.on('connection', socket => {
    console.log('User connected to web interface')
    socket.emit('initial', { 
        tokens,
        started: scrapper._started,
        initDone: scrapper._initDone,
    })

    socket.on('start', () => {
        console.log('start reveived')
        if (scrapper._started)
            return

        scrapper.start()
        io.emit('started')
    })

    socket.on('stop', () => {
        console.log('stop reveived')
        if (!scrapper._started)
            return

        scrapper.stop()
        io.emit('stopped')
    })


    socket.on('disconnect', () => {
        console.log('User disconnected from web interface')
    })
})

http.listen(3000, () => {
    console.log('listening on *:3000')
})
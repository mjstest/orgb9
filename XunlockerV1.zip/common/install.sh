ui_print "" 
ui_print "- Preparing Xunlocker -"
ui_print ""
sleep 0.5
ui_print "- ( Vol -DOWN Select / Vol +UP Next )"
sleep 1
ui_print ""
ui_print "- Select Unlocker -️"
sleep 0.5
ui_print ""
ui_print "  1. Props (ONLY FOR 90FPS)"
sleep 0.5
ui_print ""
ui_print "  2. Config (FOR HDR+EXTREME)"
sleep 0.5
ui_print ""
ui_print "  3. Props + Config"
sleep 0.5
ui_print ""
sleep 0.5
ui_print " Select: "
EM=1
while true; do
 ui_print "  $EM"
 if $VKSEL; then
  EM=$((EM + 1))
 else 
  break
 fi
 if [ $EM -gt 3 ]; then
  EM=1
 fi
done
ui_print " Selected: $EM "
#
case $EM in
 1 ) FCTEXTAD3="Props"; mv $MODPATH/s.prop $MODPATH/system.prop && rm -r $MODPATH/system;;
 2 ) FCTEXTAD3="Config"; rm $MODPATH/s.prop;;
 3 ) FCTEXTAD3="Props + Config"; mv $MODPATH/s.prop $MODPATH/system.prop;;
esac
ui_print "- Installed : $FCTEXTAD3 "
sleep 0.5
ui_print ""
ui_print "- Detecting Game Version -"
if [ $EM != 1 ]; then
  gpath="/data/media/0/Android/data"
	if [ -d $gpath/com.tencent.ig ]; then
	echo "pkg=com.tencent.ig
	emy" >> $MODPATH/system/bin/pubgm
	ui_print ""
	ui_print "- Applying Config for PUBGM GL "
	fi
	if [ -d $gpath/com.pubg.imobile ]; then
	echo "pkg=com.pubg.imobile
	emy" >> $MODPATH/system/bin/pubgm
	ui_print ""
	ui_print "- Applying Config for BATTLEGROUND INDIA "
	fi
	if [ -d $gpath/com.pubg.krmobile ]; then
	echo "pkg=com.pubg.krmobile
	emy" >> $MODPATH/system/bin/pubgm
	ui_print ""
	ui_print "- Applying Config for PUBGM KR "
	fi
	if [ -d $gpath/com.vng.pubgmobile ]; then
	echo "pkg=com.vng.pubgmobile
	emy" >> $MODPATH/system/bin/pubgm
	ui_print ""
	ui_print "- Applying Config for PUBGM VNG "
	fi
	sleep 1
	sh $MODPATH/system/bin/pubgm
fi
ui_print ""
sleep 1
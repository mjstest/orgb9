#!/system/bin/sh
MODP=/data/adb/modules/Xunlocker
if [ -d $MODP ]; then
ui_print "" 
ui_print "- Uninstalling Module -"
ui_print "" 
#BGMI
rm -f /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
#GL
rm -f /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
#KR
rm -f /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini
#VNG
rm -f /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/EnjoyCJZC.ini

touch $MODP/disable
rm -rf $MODP
sleep 2
ui_print "- Done -" 
exit
fi
sleep 1
ui_print " "
ui_print "*****************************************************"
ui_print "  " 
ui_print "  × Xunlocker "
sleep 0.9
ui_print "  " 
ui_print "  USE CONFIG+PROP TO UNLOCK HDR+EXTREME  "
ui_print "  " 
ui_print "*****************************************************"
sleep 0.9

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/system/bin/pubgm 0 2000 0755 0755
}
SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
postfs=$TMPDIR/post-fs-data.sh
. $TMPDIR/functions.sh

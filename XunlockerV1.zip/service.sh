#!/system/bin/sh

# if Magisk change its mount point in the future
MODDIR=${0%/*}
# This script will be executed in late_start service mode

sleep 50
pubgm
